#include<stdio.h>
int main(){
	double x; int i,n;

	printf("For Bessel of first kind, J0(x),\n");
	printf("                                 Enter x : "); scanf("%lf",&x);
	printf("                                 Accuracy: "); scanf("%d", &n);
	double result = 1, xx = (x*x)/4;

	// Using Horner's Method
	for(i=n-1;i>0;i-=1){
		result = 1 - ((result * xx) / (i*i));
	}
	printf("J0(%.4lf) = %.8lf \n",x,result);
	return 0;
}
