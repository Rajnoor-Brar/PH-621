#pragma once
double logE(double x){ 

	if (x <= 0.0){printf("\n \t Warning: logE(x) is only defined for positive numbers. \n");return 0;} 
        // proper error handling requires other libraries

        int n=1000,i;
        double precision=1e-12, ln2=0.6931471805599453;
        int pow2=0;

        while(x>2){ x/=2; pow2++;}
        while(x<0.5){ x*=2; pow2--;}
        // series is most accurate for small x, but too close to 0 is also risky

        double term=(x-1)/(x+1), xx= term*term, result=term;

        for (i=3;i<=n;i+=2){
                term*=xx;
                result += term/i;
                if (term==0){break;}
                if((term>=0 && term<precision) || (term<0 && -1*term<precision)){break;}
        }

        return ((2*result)+(ln2*pow2));

}
